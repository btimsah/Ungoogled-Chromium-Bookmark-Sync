# Aptosity Bookmarks (Chrome Extension)

A window into your bookmarks stored at **aptosity.com**.

## What it does

- Sign in to your Aptosity account from inside the extension's popup (sync token only — site URL is hardcoded to aptosity.com).
- Your bookmarks are fetched from aptosity.com and rendered as a 2-column grid of folder cards and bookmark cards.
- A local cache lets you keep browsing when you're offline — the popup opens instantly, even before the network responds.
- **Add, edit, delete, and move bookmarks and folders** right from the popup. Every change syncs back to aptosity.com immediately.
- **Bookmark this page** — click the + button dropdown to instantly save the current tab as a bookmark, with its title and URL pre-filled.
- **Add custom bookmark** — add a bookmark with any URL you type in manually.
- **Move to folder** — hover any bookmark or folder card to reveal the move action (↑ icon, blue hover). Choose any folder or root as the destination. Circular moves are prevented.
- **Set any folder as your root** — the popup will always open at that folder. Useful if you keep your real bookmarks inside a sub-folder.
- The extension does NOT touch your browser's bookmarks. The one-time "Import all from browser" action in Settings is the only thing that reads `chrome.bookmarks`, and it pushes the result to aptosity.com (overwriting your profile there).

## Header

The popup header is centered around the **Aptosity ♥ Bookmarks** title — with the heart.png logo sitting between the two words. Two 26px icon buttons sit on the left of the title, two on the right:
- **Left:** Search (filter the current view), Add (dropdown: Bookmark this page / Add custom bookmark / Add folder)
- **Right:** Refresh (re-pull from aptosity.com), Settings (sign in / out, root folder, seed from browser)

The footer's "Manage at Aptosity" banner links to aptosity.com/sync.

## Add dropdown

Clicking the **+** button opens a dropdown with three options:
1. **Bookmark this page** — grabs the active tab's URL and title, opens the Add modal pre-filled. One-click bookmarking.
2. **Add custom bookmark** — opens the Add modal with empty fields for you to type any URL.
3. **Add folder** — opens the Add modal in folder mode.

## Move to folder

On any bookmark or folder card, hover to reveal four actions:
1. **Move** (↑ icon, blue hover) — opens the Move modal showing the full folder tree. Select "Root (top level)" or any folder as the destination. The current parent is greyed out. You cannot move a folder into itself or its descendants.
2. **Set as root** (house icon, green hover, folders only) — marks this folder as your "home".
3. **Edit** (pencil icon)
4. **Delete** (trash icon, pink hover)

## Root folder

When a root folder is set:
- The popup opens directly into that folder on every launch
- A green "home" button appears in the nav bar — click it to jump back to your root folder from anywhere
- In Settings, the "Root folder" row shows the current root and a Reset button to return to top-level

## Permissions

| Permission | Why |
|------------|-----|
| `storage` | Cache your bookmark tree locally + store your token + root folder preference |
| `favicon` | Render favicons next to each bookmark |
| `tabs` | Open bookmarks in new tabs when you click them; read current tab for "Bookmark this page" |
| `activeTab` | Access the active tab's URL/title for the "Bookmark this page" feature |
| `bookmarks` | Used ONLY by the one-time "Import all from browser" action in Settings |
| `https://aptosity.com/*` | Call the aptosity.com REST API |

## Files

```
manifest.json
background.js         # API client + storage + cache + root folder + move + current tab
popup/
  popup.html          # popup markup (header, add dropdown, settings, search, nav, grid, footer, add/edit modal, move modal)
  popup.js            # state, render, sign-in, refresh, seed, CRUD, move, bookmark-this-page, root folder
styles/
  popup.css           # all popup styles (dark-purple glassmorphism)
icons/
  icon16.png  icon32.png  icon48.png  icon128.png   # extension icons (Heart.png)
  heart.png                                           # 28px heart for in-popup header use
```

## Pairs with

The **Aptosty Sync** WordPress plugin (install on aptosity.com). That plugin provides:
- The `/sync` page where users sign in with Google and copy their sync token
- The `bookmarks.html` upload feature
- The in-plugin Bookmarks tab (browse / search / add / edit / delete / move bookmarks on the web)
- The REST API this extension calls (`/wp-json/aptosity/v1/...`)
