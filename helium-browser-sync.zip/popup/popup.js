/**
 * Aptosity Bookmarks – popup script.
 *
 * The popup opens DIRECTLY into the bookmark list when signed in (no
 * need to click anywhere first). Bookmarks are cached locally so the
 * list appears instantly on every popup open; a background refresh
 * pulls the latest from aptosity.com.
 *
 * The user can add / edit / delete / move bookmarks and folders here.
 * Every mutation is POSTed to aptosity.com immediately and the cache
 * is updated from the server's response.
 *
 * v3.0.0 — Added: "Bookmark this page" dropdown, custom bookmark,
 *          and move-to-folder functionality.
 */

(function () {
  'use strict';

  // ── Element helpers ─────────────────────────────────────────
  var $ = function (id) { return document.getElementById(id); };

  var listEl = $('bookmark-list');
  var searchEl = $('search');
  var searchToggle = null; // No longer used — search is always visible
  var searchRow = document.getElementById('search-row');
  var navBar = $('nav-bar');
  var navTitle = $('nav-title');
  var navCount = $('nav-count');
  var backBtn = $('back-btn');
  var navAddBtn = $('nav-add-btn');
  var settingsToggle = $('settings-toggle');
  var settingsPanel = $('settings-panel');
  var refreshBtn = $('refresh-btn');
  var addBtn = $('add-btn');

  // Add dropdown
  var addDropdown = $('add-dropdown');
  var addPageBtn = $('add-page-btn');
  var addCustomBtn = $('add-custom-btn');
  var addFolderBtn = $('add-folder-btn');

  var signinBlock = $('signin-block');
  var accountBlock = $('account-block');
  var premiumBlock = $('premium-block');
  var cfgToken = $('cfg-token');
  var cfgSave = $('cfg-save');
  var cfgSignout = $('cfg-signout');
  var cfgImport = $('cfg-import-browser');
  var cfgExport = $('cfg-export-bookmarks');
  var exportResult = $('export-result');
  var cfgSyncExt = document.querySelectorAll('.js-sync-extensions');
  var cfgDownloadZip = $('cfg-download-ext-zip');
  var syncExtResult = $('sync-ext-result');
  var syncExtResultPremium = $('sync-ext-result-premium');
  var signinError = $('signin-error');
  var importResult = $('import-result');
  var cfgResetRoot = $('cfg-reset-root');
  var rootFolderName = $('root-folder-name');
  var rootHomeBtn = $('root-home-btn');

  // Premium-block elements
  var premiumSubscribeLink = $('premium-subscribe-link');
  var premiumStatusDetail = $('premium-status-detail');
  var cfgPremiumRefresh = $('cfg-premium-refresh');
  var cfgSignoutPremium = $('cfg-signout-premium');

  var accountName = $('account-name');
  var accountEmail = $('account-email');
  var accountAvatar = $('account-avatar');

  // Modal elements
  var modalOverlay = $('modal-overlay');
  var modalTitleEl = $('modal-title');
  var modalTitleInput = $('modal-title-input');
  var modalUrlInput = $('modal-url-input');
  var modalUrlGroup = $('modal-url-group');
  var modalTypeGroup = $('modal-type-group');
  var modalTypeBookmark = $('modal-type-bookmark');
  var modalTypeFolder = $('modal-type-folder');
  var modalError = $('modal-error');
  var modalCancel = $('modal-cancel');
  var modalSave = $('modal-save');

  // Move modal elements
  var moveOverlay = $('move-overlay');
  var moveModalTitle = $('move-modal-title');
  var moveHint = $('move-hint');
  var moveFolderList = $('move-folder-list');
  var moveError = $('move-error');
  var moveCancel = $('move-cancel');

  // ── State ───────────────────────────────────────────────────
  var currentFilter = '';
  var navStack = [];
  var currentFolderNode = null;  // null = virtual root
  var rootTree = null;
  var connectionInfo = null;

  // Root folder — user can set any folder as their "home" so the popup
  // always opens there. Stored as { id, title } in chrome.storage.local.
  var rootFolder = null;  // null = top-level (default)

  // Modal state
  var modalMode = 'add';          // 'add' | 'edit'
  var modalType = 'bookmark';     // 'bookmark' | 'folder'
  var modalEditNode = null;       // node being edited
  var modalAddParent = null;      // parent node for 'add' mode (null = root)

  // Move modal state
  var moveNode = null;            // the node being moved

  // ── Toast ───────────────────────────────────────────────────
  function toast(msg, type) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast visible' + (type ? ' ' + type : '');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.className = 'toast'; }, 2800);
  }

  // ── Message to background ───────────────────────────────────
  function send(message) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage(message, function (res) {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!res || !res.ok) {
          var err = new Error((res && res.error) || 'Unknown error');
          err.code = res && res.code;
          err.status = res && res.status;
          reject(err);
          return;
        }
        resolve(res);
      });
    });
  }

  // ── Helpers ─────────────────────────────────────────────────
  function initials(name) {
    if (!name) return '?';
    var parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  function faviconUrl(url) {
    try {
      return chrome.runtime.getURL('/_favicon/?pageUrl=' + encodeURIComponent(url) + '&size=16');
    } catch (e) {
      return '';
    }
  }

  var FALLBACK_ICON = 'data:image/svg+xml,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10A15.3 15.3 0 0 1 12 2z"/></svg>'
  );

  function makeFaviconImg(url) {
    var img = document.createElement('img');
    img.className = 'bookmark-favicon';
    img.src = faviconUrl(url);
    img.alt = '';
    img.loading = 'lazy';
    img.dataset.tries = '0';
    img.dataset.nodeUrl = url;
    img.onerror = function () {
      var tries = Number(this.dataset.tries) + 1;
      this.dataset.tries = String(tries);
      if (tries === 1) {
        try {
          var u = new URL(this.dataset.nodeUrl);
          this.src = 'https://www.google.com/s2/favicons?domain=' + u.hostname + '&sz=32';
        } catch (e) {
          this.src = FALLBACK_ICON;
          this.onerror = null;
        }
      } else if (tries === 2) {
        try {
          this.src = chrome.runtime.getURL('/_favicon/?pageUrl=' + encodeURIComponent(this.dataset.nodeUrl) + '&size=32');
        } catch (e) {
          this.src = FALLBACK_ICON;
          this.onerror = null;
        }
      } else {
        this.src = FALLBACK_ICON;
        this.onerror = null;
      }
    };
    return img;
  }

  // ── Add dropdown ────────────────────────────────────────────
  function closeAddDropdown() {
    addDropdown.classList.remove('visible');
  }

  // Close dropdown when clicking outside
  document.addEventListener('click', function (e) {
    if (addDropdown.classList.contains('visible') &&
        !addDropdown.contains(e.target) &&
        e.target !== addBtn && !addBtn.contains(e.target)) {
      closeAddDropdown();
    }
  });

  addBtn.addEventListener('click', function (e) {
    e.stopPropagation();
    if (!connectionInfo) {
      settingsPanel.classList.add('visible');
      settingsToggle.classList.add('active');
      return;
    }
    // Toggle dropdown
    var opening = !addDropdown.classList.contains('visible');
    addDropdown.classList.toggle('visible');
    if (opening) {
      // Close search/settings if open
      searchRow.classList.remove('visible');
      
      settingsPanel.classList.remove('visible');
      settingsToggle.classList.remove('active');
    }
  });

  // "Bookmark this page" — grabs the current tab URL/title
  addPageBtn.addEventListener('click', async function () {
    closeAddDropdown();
    try {
      var res = await send({ type: 'GET_CURRENT_TAB' });
      var tab = res.tab;
      if (!tab || !tab.url) {
        toast('Could not get current page URL', 'error');
        return;
      }
      // Skip chrome:// and extension pages
      if (!/^https?:\/\//i.test(tab.url)) {
        toast('Cannot bookmark browser-internal pages', 'error');
        return;
      }
      // Open add modal pre-filled with the current page info
      openAddModalForPage(tab.url, tab.title || '');
    } catch (e) {
      toast('Could not get current page: ' + (e.message || 'error'), 'error');
    }
  });

  // "Add custom bookmark" — opens the add modal with empty fields
  addCustomBtn.addEventListener('click', function () {
    closeAddDropdown();
    openAddModal();
  });

  // "Add folder" — opens the add modal in folder mode
  addFolderBtn.addEventListener('click', function () {
    closeAddDropdown();
    openAddModalForFolder();
  });

  // ── Settings panel ──────────────────────────────────────────
  settingsToggle.addEventListener('click', function () {
    var opening = !settingsPanel.classList.contains('visible');
    settingsPanel.classList.toggle('visible');
    settingsToggle.classList.toggle('active');
    if (opening) {
      // Close search/dropdown if open
      searchRow.classList.remove('visible');
      
      closeAddDropdown();
      searchEl.value = '';
      currentFilter = '';
      renderView();
      // Pre-fill saved token
      send({ type: 'GET_STATE' }).then(function (res) {
        var s = (res && res.state) || {};
        if (s.aptosity_token) cfgToken.value = s.aptosity_token;
      }).catch(function () {});
    }
  });

  // ── Sign in ─────────────────────────────────────────────────
  cfgSave.addEventListener('click', async function () {
    var token = cfgToken.value.trim();
    signinError.textContent = '';
    signinError.className = 'setting-hint';

    if (!token) {
      signinError.textContent = 'Enter your sync token.';
      signinError.className = 'setting-hint error';
      return;
    }

    cfgSave.disabled = true;
    cfgSave.textContent = 'Signing in…';

    try {
      await send({ type: 'SAVE_TOKEN', token: token });

      // Try TEST_CONNECTION. If it throws PREMIUM_REQUIRED, that's NOT a
      // sign-in failure — the token is valid, the user just doesn't have
      // premium. We show the premium-required UI instead of an error.
      // We also auto-retry once after 2s in case the user just paid and
      // the IPN is still processing.
      var test;
      try {
        test = await send({ type: 'TEST_CONNECTION' });
      } catch (e) {
        if (e.code === 'PREMIUM_REQUIRED') {
          // Auto-retry once after 2 seconds (IPN may have just fired).
          await new Promise(function (r) { setTimeout(r, 2000); });
          try {
            test = await send({ type: 'TEST_CONNECTION' });
          } catch (e2) {
            if (e2.code === 'PREMIUM_REQUIRED') {
              // Token is valid, but premium is required. Show the premium UI.
              connectionInfo = { user: e2.premium || {} };
              showPremiumRequired(e2.premium || null);
              toast('Signed in — premium required', 'error');
              return;
            }
            throw e2;
          }
        } else {
          throw e;
        }
      }

      connectionInfo = test.status;

      // Try to fetch bookmarks. If PREMIUM_REQUIRED, show premium UI
      // (not an error — the user is signed in, just not premium).
      try {
        await send({ type: 'FETCH_BOOKMARKS' });
      } catch (e) {
        if (e.code === 'PREMIUM_REQUIRED') {
          showPremiumRequired(null);
          toast('Signed in — premium required', 'error');
          return;
        }
        throw e;
      }

      var state = (await send({ type: 'GET_STATE' })).state || {};
      rootTree = state.aptosity_cached_tree || [];
      // Load saved root folder (if any)
      rootFolder = state.aptosity_root_folder || null;
      updateRootFolderUI();
      showSignedIn();
      // IMPORTANT: close the settings panel and show bookmarks directly.
      settingsPanel.classList.remove('visible');
      settingsToggle.classList.remove('active');
      // If a root folder is set, navigate to it; otherwise go to top.
      if (rootFolder) {
        navigateToRootFolder();
      } else {
        currentFolderNode = null;
        navStack = [];
        updateNavBar();
        renderView();
      }
      toast('Signed in as ' + (connectionInfo.user.displayName || 'user'), 'success');
    } catch (e) {
      var msg = e.code === 'NOT_CONFIGURED' ? 'Enter token first'
              : e.code === 'HTTP_401' ? 'Token rejected by server'
              : e.code === 'PREMIUM_REQUIRED' ? 'Premium required — visit aptosity.com/sync to subscribe'
              : (e.message || 'Sign-in failed');
      signinError.textContent = msg;
      signinError.className = 'setting-hint error';
    } finally {
      cfgSave.disabled = false;
      cfgSave.textContent = 'Sign in';
    }
  });

  // ── Sign out ────────────────────────────────────────────────
  cfgSignout.addEventListener('click', async function () {
    if (!confirm('Sign out of Aptosity?\n\nYour cached bookmarks will be removed from this browser. Your account on aptosity.com is not affected.')) return;
    try {
      await send({ type: 'SIGN_OUT' });
      connectionInfo = null;
      rootTree = null;
      currentFolderNode = null;
      navStack = [];
      rootFolder = null;
      cfgToken.value = '';
      updateRootFolderUI();
      showSignedOut();
      renderView();
      toast('Signed out', 'success');
    } catch (e) {
      toast('Could not sign out: ' + e.message, 'error');
    }
  });

  // ── Premium-block: "Sign out" button (same behavior as cfgSignout) ──
  if (cfgSignoutPremium) {
    cfgSignoutPremium.addEventListener('click', async function () {
      if (!confirm('Sign out of Aptosity?\n\nYour cached bookmarks will be removed from this browser. Your account on aptosity.com is not affected.')) return;
      try {
        await send({ type: 'SIGN_OUT' });
        connectionInfo = null;
        rootTree = null;
        currentFolderNode = null;
        navStack = [];
        rootFolder = null;
        cfgToken.value = '';
        updateRootFolderUI();
        showSignedOut();
        renderView();
        toast('Signed out', 'success');
      } catch (e) {
        toast('Could not sign out: ' + e.message, 'error');
      }
    });
  }

  // ── Premium-block: "I've paid — refresh" button ─────────────
  // Forces a fresh /status call (bypassing the 7-day cache) and either
  // resumes normal sync (if premium is now active) or updates the status detail.
  if (cfgPremiumRefresh) {
    cfgPremiumRefresh.addEventListener('click', async function () {
      if (premiumStatusDetail) {
        premiumStatusDetail.textContent = 'Re-checking your license…';
        premiumStatusDetail.classList.remove('is-active');
      }
      try {
        var res = await send({ type: 'REFRESH_PREMIUM' });
        var premium = (res && res.premium) || null;
        if (premium && premium.isActive) {
          showPremiumRequired(premium); // shows "active" detail
          // Re-trigger the normal boot flow to load bookmarks.
          setTimeout(function () { window.location.reload(); }, 800);
        } else {
          showPremiumRequired(premium);
        }
      } catch (e) {
        if (premiumStatusDetail) {
          premiumStatusDetail.textContent = 'Could not check license: ' + (e.message || 'network error');
        }
      }
    });
  }

  // ── Import all from browser (seed) ──────────────────────────
  cfgImport.addEventListener('click', async function () {
    var ok = confirm(
      'Import all bookmarks from this browser to Aptosity?\n\n' +
      'This will REPLACE your Aptosity bookmark profile with this browser\'s current bookmarks.\n\n' +
      'Bookmarks already in your browser are NOT affected.'
    );
    if (!ok) return;

    cfgImport.disabled = true;
    cfgImport.textContent = 'Importing…';
    importResult.textContent = '';
    importResult.className = 'setting-hint';

    try {
      var res = await send({ type: 'SEED_FROM_BROWSER' });
      var count = (res.result && res.result.itemCount) || 0;
      importResult.textContent = 'Imported ' + count + ' bookmarks.';
      importResult.className = 'setting-hint success';
      var state = (await send({ type: 'GET_STATE' })).state || {};
      rootTree = state.aptosity_cached_tree || [];
      // If a root folder is set, navigate to it; otherwise go to top.
      if (rootFolder) {
        navigateToRootFolder();
      } else {
        currentFolderNode = null;
        navStack = [];
        updateNavBar();
        renderView();
      }
      toast('Imported ' + count + ' bookmarks', 'success');
    } catch (e) {
      importResult.textContent = 'Failed: ' + (e.message || 'error');
      importResult.className = 'setting-hint error';
      toast('Import failed: ' + (e.message || 'error'), 'error');
    } finally {
      cfgImport.disabled = false;
      cfgImport.textContent = 'Import all from browser';
    }
  });

  // ── Export bookmarks.html (download from cached tree) ──────
  if (cfgExport) {
    cfgExport.addEventListener('click', async function () {
      cfgExport.disabled = true;
      var originalText = cfgExport.textContent;
      cfgExport.textContent = 'Exporting…';
      if (exportResult) {
        exportResult.textContent = 'Preparing your bookmarks.html…';
        exportResult.className = 'setting-hint';
      }

      try {
        var res = await send({ type: 'EXPORT_BOOKMARKS_HTML' });
        var count = (res.result && res.result.itemCount) || 0;
        var filename = (res.result && res.result.filename) || 'bookmarks.html';
        if (exportResult) {
          exportResult.textContent = 'Downloaded ' + filename + ' (' + count + ' bookmarks).';
          exportResult.className = 'setting-hint success';
        }
        toast('Exported ' + count + ' bookmarks', 'success');
      } catch (e) {
        var msg = e.message || 'error';
        if (e.code === 'EMPTY_TREE') {
          msg = 'No bookmarks to export. Import or seed first.';
        }
        if (exportResult) {
          exportResult.textContent = 'Failed: ' + msg;
          exportResult.className = 'setting-hint error';
        }
        toast('Export failed: ' + msg, 'error');
      } finally {
        cfgExport.disabled = false;
        cfgExport.textContent = originalText;
      }
    });
  }

  // ── Sync Extensions (available to ALL logged-in users) ─────
  // Wire up every button with the .js-sync-extensions class
  // (there's one in account-block for premium users, and one in
  // premium-block for non-premium users).
  cfgSyncExt.forEach(function (btn) {
    btn.addEventListener('click', async function () {
      btn.disabled = true;
      var originalText = btn.textContent;
      btn.textContent = 'Syncing…';

      // Update whichever result element is visible.
      function setResult(msg, type) {
        var target = syncExtResult;
        if (!target || target.offsetParent === null) {
          target = syncExtResultPremium;
        }
        if (target) {
          target.textContent = msg;
          target.className = 'setting-hint' + (type ? ' ' + type : '');
        }
      }

      setResult('Reading installed extensions…', '');

      try {
        var res = await send({ type: 'SYNC_EXTENSIONS' });
        var count = (res && res.result && res.result.count) || 0;
        setResult('Synced ' + count + ' extension' + (count === 1 ? '' : 's') + ' to your Extensions folder.', 'success');
        toast('Synced ' + count + ' extensions', 'success');

        // Refresh the bookmark tree in the popup (if visible).
        try {
          var state = (await send({ type: 'GET_STATE' })).state || {};
          rootTree = state.aptosity_cached_tree || [];
          renderView();
        } catch (e2) {
          // Ignore — may be in premium-block where renderView isn't relevant.
        }
      } catch (e) {
        var msg = e.message || 'error';
        if (e.code === 'PREMIUM_REQUIRED') {
          msg = 'Premium required to sync extensions.';
        }
        setResult('Failed: ' + msg, 'error');
        toast('Sync failed: ' + msg, 'error');
      } finally {
        btn.disabled = false;
        btn.textContent = originalText;
      }
    });
  });

  // ── Download Extension .zip (premium feature) ───────────────
  if (cfgDownloadZip) {
    cfgDownloadZip.addEventListener('click', async function () {
      cfgDownloadZip.disabled = true;
      var originalText = cfgDownloadZip.textContent;
      cfgDownloadZip.textContent = 'Loading…';

      try {
        var res = await send({ type: 'GET_EXTENSION_ZIP_URL' });
        var zipUrl = res && res.result && res.result.zipUrl;
        if (!zipUrl) {
          toast('No .zip URL configured', 'error');
          if (syncExtResult) {
            syncExtResult.textContent = 'No .zip URL configured by the site admin.';
            syncExtResult.className = 'setting-hint error';
          }
          return;
        }
        // Open the ZIP URL in a new tab to trigger download.
        chrome.tabs.create({ url: zipUrl });
        toast('Opening download…', 'success');
      } catch (e) {
        var msg = e.message || 'error';
        if (e.code === 'PREMIUM_REQUIRED') {
          msg = 'Premium required to download the extension.';
        }
        toast('Download failed: ' + msg, 'error');
        if (syncExtResult) {
          syncExtResult.textContent = 'Failed: ' + msg;
          syncExtResult.className = 'setting-hint error';
        }
      } finally {
        cfgDownloadZip.disabled = false;
        cfgDownloadZip.textContent = originalText;
      }
    });
  }

  // ── Refresh button ──────────────────────────────────────────
  refreshBtn.addEventListener('click', async function () {
    if (refreshBtn.classList.contains('spinning')) return;
    if (!connectionInfo) {
      settingsPanel.classList.add('visible');
      settingsToggle.classList.add('active');
      return;
    }
    refreshBtn.classList.add('spinning');
    try {
      await send({ type: 'FETCH_BOOKMARKS' });
      var state = (await send({ type: 'GET_STATE' })).state || {};
      rootTree = state.aptosity_cached_tree || [];
      refreshCurrentFolderNode();
      // If a root folder is set, navigate to it; otherwise reset to top.
      if (rootFolder) {
        navigateToRootFolder();
      } else {
        currentFolderNode = null;
        navStack = [];
        updateNavBar();
        renderView();
      }
      toast('Bookmarks refreshed', 'success');
    } catch (e) {
      toast('Refresh failed: ' + (e.message || 'error'), 'error');
    } finally {
      refreshBtn.classList.remove('spinning');
    }
  });

  // ── Home button (reset to start screen) ────────────────────
  var homeBtn = $('home-btn');
  if (homeBtn) {
    homeBtn.addEventListener('click', function () {
      // Close settings panel if open.
      settingsPanel.classList.remove('visible');
      settingsToggle.classList.remove('active');
      closeAddDropdown();
      // Clear search + nav.
      currentFilter = '';
      searchEl.value = '';
      currentFolderNode = null;
      navStack = [];
      if (rootFolder) {
        navigateToRootFolder();
      } else {
        renderView();
      }
      updateNavBar();
    });
  }

  // ── Search (always visible — no toggle needed) ─────────────
  searchEl.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      searchEl.value = '';
      currentFilter = '';
      renderView();
    }
  });

  searchEl.addEventListener('input', function () {
    currentFilter = searchEl.value.trim();
    renderView();
  });

  // ── Back button ─────────────────────────────────────────────
  backBtn.addEventListener('click', navigateBack);
  navAddBtn.addEventListener('click', function () { openAddModal(); });

  function navigateBack() {
    if (navStack.length === 0) return;
    currentFolderNode = navStack.pop();
    updateNavBar();
    updateRootFolderUI();
    renderView();
  }

  function navigateIntoFolder(node) {
    navStack.push(currentFolderNode);
    currentFolderNode = node;
    currentFilter = '';
    searchEl.value = '';
    searchRow.classList.remove('visible');
    
    closeAddDropdown();
    updateNavBar();
    updateRootFolderUI();
    renderView();
  }

  function updateNavBar() {
    if (currentFolderNode && currentFolderNode.id !== '__root__') {
      navBar.classList.add('visible');
      navTitle.textContent = currentFolderNode.title || 'Unnamed Folder';
      var kids = currentFolderNode.children || [];
      var c = 0;
      (function cnt(nodes) {
        for (var i = 0; i < nodes.length; i++) {
          if (nodes[i].url) c++;
          else if (nodes[i].children) cnt(nodes[i].children);
        }
      })(kids);
      navCount.textContent = c + ' item' + (c !== 1 ? 's' : '');
    } else {
      navBar.classList.remove('visible');
    }
  }

  // ── Open all in folder (context menu) ───────────────────────
  function openAllInFolder(node) {
    var urls = [];
    (function collect(nodes) {
      for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].url) urls.push(nodes[i].url);
        else if (nodes[i].children) collect(nodes[i].children);
      }
    })(node.children || []);
    for (var i = 0; i < urls.length; i++) {
      chrome.tabs.create({ url: urls[i] });
    }
  }

  // ── Bookmark card ───────────────────────────────────────────
  function renderBookmarkCard(node) {
    var wrap = document.createElement('div');
    wrap.className = 'card-wrap';

    var a = document.createElement('a');
    a.className = 'bookmark-card';
    a.href = node.url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';

    a.appendChild(makeFaviconImg(node.url));

    var span = document.createElement('span');
    span.className = 'bookmark-title';
    span.textContent = node.title || node.url;
    a.appendChild(span);

    // Middle-click: open in new tab
    a.addEventListener('mousedown', function (e) {
      if (e.button === 1) {
        e.preventDefault();
        e.stopPropagation();
        chrome.tabs.create({ url: node.url });
      }
    });

    wrap.appendChild(a);

    // Move / Edit / delete hover buttons
    var actions = document.createElement('div');
    actions.className = 'card-actions';

    var moveBtn = document.createElement('button');
    moveBtn.className = 'card-action-btn card-action-btn-move';
    moveBtn.title = 'Move to another folder';
    moveBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 14 21 14 21 20"/><polyline points="9 14 3 14 3 20"/><line x1="12" y1="3" x2="12" y2="14"/><polyline points="15 7 12 3 9 7"/></svg>';
    moveBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openMoveModal(node);
    });

    var editBtn = document.createElement('button');
    editBtn.className = 'card-action-btn';
    editBtn.title = 'Edit';
    editBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>';
    editBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openEditModal(node);
    });

    var delBtn = document.createElement('button');
    delBtn.className = 'card-action-btn card-action-btn-danger';
    delBtn.title = 'Delete';
    delBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/></svg>';
    delBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      handleDelete(node);
    });

    actions.appendChild(moveBtn);
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    wrap.appendChild(actions);

    return wrap;
  }

  // ── Folder card ─────────────────────────────────────────────
  function renderFolderCard(node) {
    var wrap = document.createElement('div');
    wrap.className = 'card-wrap';

    var div = document.createElement('div');
    div.className = 'folder-card';

    var iconWrap = document.createElement('div');
    iconWrap.className = 'folder-icon-wrap';

    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '14');
    svg.setAttribute('height', '14');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z');
    svg.appendChild(path);
    iconWrap.appendChild(svg);

    var label = document.createElement('div');
    label.className = 'folder-label';
    label.textContent = node.title || 'Unnamed Folder';

    div.appendChild(iconWrap);
    div.appendChild(label);

    div.addEventListener('click', function () {
      navigateIntoFolder(node);
    });

    div.addEventListener('contextmenu', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openAllInFolder(node);
    });

    wrap.appendChild(div);

    // Move / set-as-root / Edit / delete hover buttons
    var actions = document.createElement('div');
    actions.className = 'card-actions';

    var moveBtn = document.createElement('button');
    moveBtn.className = 'card-action-btn card-action-btn-move';
    moveBtn.title = 'Move to another folder';
    moveBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 14 21 14 21 20"/><polyline points="9 14 3 14 3 20"/><line x1="12" y1="3" x2="12" y2="14"/><polyline points="15 7 12 3 9 7"/></svg>';
    moveBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openMoveModal(node);
    });

    var rootBtn = document.createElement('button');
    rootBtn.className = 'card-action-btn card-action-btn-success';
    rootBtn.title = rootFolder && rootFolder.id === node.id
      ? 'This is your root folder'
      : 'Set as my root folder (popup always opens here)';
    if (rootFolder && rootFolder.id === node.id) {
      rootBtn.classList.add('is-active');
    }
    rootBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>';
    rootBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      handleSetRoot(node);
    });

    var editBtn = document.createElement('button');
    editBtn.className = 'card-action-btn';
    editBtn.title = 'Edit';
    editBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>';
    editBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      openEditModal(node);
    });

    var delBtn = document.createElement('button');
    delBtn.className = 'card-action-btn card-action-btn-danger';
    delBtn.title = 'Delete';
    delBtn.innerHTML = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-2 14a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L5 6"/></svg>';
    delBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      handleDelete(node);
    });

    actions.appendChild(moveBtn);
    actions.appendChild(rootBtn);
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    wrap.appendChild(actions);

    return wrap;
  }

  // ── Filter helpers ──────────────────────────────────────────
  function nodeMatchesFilter(node, filterLower) {
    if (!filterLower) return true;
    return (
      (node.title && node.title.toLowerCase().indexOf(filterLower) !== -1) ||
      (node.url && node.url.toLowerCase().indexOf(filterLower) !== -1)
    );
  }

  function folderHasMatch(node, filterLower) {
    if (nodeMatchesFilter(node, filterLower)) return true;
    if (node.children) {
      for (var i = 0; i < node.children.length; i++) {
        if (folderHasMatch(node.children[i], filterLower)) return true;
      }
    }
    return false;
  }

  // ── Render nodes into grid ──────────────────────────────────
  function renderNodesToGrid(nodes, container, filter) {
    var filterLower = filter ? filter.toLowerCase() : '';
    var grid = document.createElement('div');
    grid.className = 'bookmark-grid';

    var folders = [];
    var bookmarks = [];

    if (filterLower) {
      // When filtering, recursively walk the ENTIRE tree to find matches.
      // Folders that contain matches are shown as folder cards (clickable).
      // Individual bookmarks that match anywhere in the tree are shown.
      function walkAll(nodeList) {
        if (!Array.isArray(nodeList)) return;
        for (var i = 0; i < nodeList.length; i++) {
          var node = nodeList[i];
          if (node.children) {
            // Folder — show it if it or any descendant matches.
            if (folderHasMatch(node, filterLower)) {
              folders.push(node);
            }
            // Recurse into children to find individual bookmarks.
            walkAll(node.children);
          } else if (node.url) {
            if (nodeMatchesFilter(node, filterLower)) {
              bookmarks.push(node);
            }
          }
        }
      }
      walkAll(nodes);
    } else {
      // No filter — show direct children only (normal browsing).
      for (var i = 0; i < nodes.length; i++) {
        var node = nodes[i];
        if (node.children) {
          folders.push(node);
        } else if (node.url) {
          bookmarks.push(node);
        }
      }
    }

    for (var f = 0; f < folders.length; f++) {
      grid.appendChild(renderFolderCard(folders[f]));
    }

    if (folders.length > 0 && bookmarks.length > 0) {
      var sep = document.createElement('div');
      sep.className = 'grid-separator';
      grid.appendChild(sep);
    }

    for (var b = 0; b < bookmarks.length; b++) {
      grid.appendChild(renderBookmarkCard(bookmarks[b]));
    }

    if (grid.children.length === 0) {
      grid.appendChild(renderEmptyState(filter ? 'No matches' : 'No bookmarks here'));
    }

    container.appendChild(grid);
  }

  function renderEmptyState(msg, opts) {
    var empty = document.createElement('div');
    empty.className = 'empty-state';
    var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', '32');
    svg.setAttribute('height', '32');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1.5');
    var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', 'M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z');
    svg.appendChild(path);
    empty.appendChild(svg);
    var m = document.createElement('div');
    m.textContent = msg;
    empty.appendChild(m);
    if (opts && opts.actionBtn) {
      var wrap = document.createElement('div');
      wrap.className = 'empty-action';
      wrap.appendChild(opts.actionBtn);
      empty.appendChild(wrap);
    }
    return empty;
  }

  function renderLoadingState() {
    var loading = document.createElement('div');
    loading.className = 'loading-state';
    var spinner = document.createElement('div');
    spinner.className = 'spinner';
    loading.appendChild(spinner);
    var m = document.createElement('div');
    m.textContent = 'Loading bookmarks…';
    loading.appendChild(m);
    return loading;
  }

  // ── Main render ─────────────────────────────────────────────
  function renderView() {
    listEl.textContent = '';

    if (!connectionInfo) {
      // Not signed in — show empty state with an "Open Settings" button
      var btn = document.createElement('button');
      btn.className = 'btn btn-primary btn-sm';
      btn.textContent = 'Open Settings';
      btn.addEventListener('click', function () {
        settingsPanel.classList.add('visible');
        settingsToggle.classList.add('active');
        cfgToken.focus();
      });
      listEl.appendChild(renderEmptyState('Sign in to access your Aptosity bookmarks', { actionBtn: btn }));
      return;
    }

    if (rootTree === null) {
      listEl.appendChild(renderLoadingState());
      return;
    }

    if (rootTree.length === 0) {
      var importBtn = document.createElement('button');
      importBtn.className = 'btn btn-primary btn-sm';
      importBtn.textContent = 'Import all from browser';
      importBtn.addEventListener('click', function () {
        settingsPanel.classList.add('visible');
        settingsToggle.classList.add('active');
      });
      listEl.appendChild(renderEmptyState('Your Aptosity profile is empty', { actionBtn: importBtn }));
      return;
    }

    // Build a virtual root
    if (currentFilter) {
      renderNodesToGrid(rootTree, listEl, currentFilter);
    } else if (currentFolderNode && currentFolderNode.children) {
      renderNodesToGrid(currentFolderNode.children, listEl, '');
    } else {
      var virtualRoot = {
        id: '__root__',
        title: 'Root',
        children: rootTree.slice()
      };
      currentFolderNode = virtualRoot;
      navStack = [];
      updateNavBar();
      renderNodesToGrid(virtualRoot.children, listEl, '');
    }
  }

  // ── Account UI ──────────────────────────────────────────────
  function showSignedIn() {
    signinBlock.style.display = 'none';
    accountBlock.style.display = '';
    if (premiumBlock) premiumBlock.style.display = 'none';
    var u = (connectionInfo && connectionInfo.user) || {};
    accountName.textContent = u.displayName || 'Connected';
    accountEmail.textContent = u.email || '';
    accountAvatar.textContent = initials(u.displayName);
  }

  function showSignedOut() {
    signinBlock.style.display = '';
    accountBlock.style.display = 'none';
    if (premiumBlock) premiumBlock.style.display = 'none';
    // When signed out, settings panel must be open so the user can paste a token.
    settingsPanel.classList.add('visible');
    settingsToggle.classList.add('active');
  }

  /**
   * Show the "Premium required" state. Called when the server returns
   * 402 aptosity_premium_required — the user is signed in but their
   * license is inactive / expired.
   *
   * @param {object|null} premium Premium status from /status response.
   */
  function showPremiumRequired(premium) {
    signinBlock.style.display = 'none';
    accountBlock.style.display = 'none';
    if (premiumBlock) premiumBlock.style.display = '';
    // Open settings panel so premium-block is visible.
    settingsPanel.classList.add('visible');
    settingsToggle.classList.add('active');

    if (premiumStatusDetail) {
      if (premium && premium.isActive) {
        premiumStatusDetail.textContent = 'Premium active — sync should work now.';
        premiumStatusDetail.classList.add('is-active');
      } else if (premium && premium.plan) {
        var exp = premium.expiresAt ? new Date(premium.expiresAt).toLocaleDateString() : '—';
        premiumStatusDetail.textContent = 'License expired on ' + exp + '. Renew at aptosity.com/sync.';
        premiumStatusDetail.classList.remove('is-active');
      } else {
        premiumStatusDetail.textContent = 'No active license. Subscribe at aptosity.com/sync.';
        premiumStatusDetail.classList.remove('is-active');
      }
    }

    // Kick off the preview tree fetch (or use cached data).
    initPreviewTree();
  }

  // ── Premium preview tree (locked bookmarks) ────────────────
  //
  // When the user is signed in but doesn't have premium, we fetch a
  // URL-stripped preview of their bookmark tree from /bookmarks/preview.
  // The preview shows folder structure + bookmark titles, but all
  // bookmarks are "locked" (not clickable). Folders ARE clickable so
  // the user can browse their full tree structure.

  var previewTree = null;
  var previewNavStack = []; // [{node, title}, ...]

  /**
   * Initialize the preview tree: use cached data for instant render,
   * then fetch fresh data in the background.
   */
  function initPreviewTree() {
    // If we already have previewTree in memory, just re-render.
    if (previewTree && previewTree.length > 0) {
      renderPreviewLevel();
      return;
    }

    // Try to use cached preview from storage (instant render).
    send({ type: 'GET_STATE' }).then(function (res) {
      var state = (res && res.state) || {};
      var cached = state.aptosity_cached_preview_tree || null;
      if (cached && Array.isArray(cached) && cached.length > 0) {
        previewTree = cached;
        renderPreviewLevel();
      } else {
        // No cache — show loading state and fetch.
        showPreviewLoading();
      }

      // Always fetch fresh data in the background (cheap endpoint).
      fetchPreviewTree();
    }).catch(function () {
      showPreviewError('Could not load bookmarks.');
    });
  }

  /**
   * Fetch the preview tree from the server via the background script.
   */
  function fetchPreviewTree() {
    send({ type: 'FETCH_BOOKMARKS_PREVIEW' }).then(function (res) {
      var tree = (res && res.result && res.result.tree) || [];
      previewTree = tree;
      // Reset navigation to root.
      previewNavStack = [];
      renderPreviewLevel();
    }).catch(function (e) {
      // If it's a premium-required error, that's expected — the preview
      // endpoint doesn't require premium, but the token might be invalid.
      if (e.code === 'PREMIUM_REQUIRED' || e.code === 'HTTP_401') {
        showPreviewError('Sign in to aptosity.com first.');
      } else if (e.code === 'EMPTY_TREE') {
        showPreviewEmpty();
      } else {
        showPreviewError('Could not load bookmarks. ' + (e.message || ''));
      }
    });
  }

  /**
   * Render the current level of the preview tree.
   * Uses previewNavStack to track folder navigation.
   */
  function renderPreviewLevel() {
    var listEl = document.getElementById('premium-preview-list');
    if (!listEl) return;

    if (!previewTree || previewTree.length === 0) {
      showPreviewEmpty();
      return;
    }

    // Determine current folder's children.
    var currentChildren;
    var currentTitle;

    if (previewNavStack.length === 0) {
      // Root level.
      currentChildren = previewTree;
      currentTitle = null; // root doesn't show a back button
    } else {
      var current = previewNavStack[previewNavStack.length - 1];
      currentChildren = (current.node && current.node.children) || [];
      currentTitle = current.title || 'Folder';
    }

    // Clear and render.
    listEl.innerHTML = '';

    // Back button (if inside a folder).
    if (previewNavStack.length > 0) {
      var back = document.createElement('div');
      back.className = 'premium-preview-back';
      back.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg> Back' +
        (currentTitle ? ' — ' + escapeHtmlPremium(currentTitle) : '');
      back.addEventListener('click', function () {
        previewNavStack.pop();
        renderPreviewLevel();
      });
      listEl.appendChild(back);
    }

    if (currentChildren.length === 0) {
      var empty = document.createElement('div');
      empty.className = 'premium-preview-empty';
      empty.textContent = 'This folder is empty.';
      listEl.appendChild(empty);
      return;
    }

    // Render each child node.
    for (var i = 0; i < currentChildren.length; i++) {
      listEl.appendChild(renderPreviewNode(currentChildren[i]));
    }
  }

  /**
   * Render a single preview node (folder or locked bookmark).
   */
  function renderPreviewNode(node) {
    var card = document.createElement('div');
    card.className = 'premium-preview-card';

    var isFolder = node && Array.isArray(node.children);
    var title = (node && node.title) ? node.title : 'Untitled';

    if (isFolder) {
      // Folder — clickable for navigation.
      card.classList.add('premium-preview-folder');
      var childCount = node.children.length;
      card.innerHTML =
        '<svg class="premium-preview-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>' +
        '<span class="premium-preview-name">' + escapeHtmlPremium(title) + '</span>' +
        '<span class="premium-preview-count">' + childCount + '</span>' +
        '<svg class="premium-preview-chevron" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>';

      card.addEventListener('click', function () {
        previewNavStack.push({ node: node, title: title });
        renderPreviewLevel();
      });
    } else {
      // Bookmark — locked, not clickable.
      card.classList.add('premium-preview-bookmark');
      card.innerHTML =
        '<svg class="premium-preview-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>' +
        '<span class="premium-preview-name">' + escapeHtmlPremium(title) + '</span>' +
        '<svg class="premium-preview-lock" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';

      card.addEventListener('click', function (e) {
        e.preventDefault();
        toast('Premium required to open bookmarks', 'error');
      });
    }

    return card;
  }

  function showPreviewLoading() {
    var listEl = document.getElementById('premium-preview-list');
    if (!listEl) return;
    listEl.innerHTML = '<div class="premium-preview-loading">Loading your bookmarks…</div>';
  }

  function showPreviewEmpty() {
    var listEl = document.getElementById('premium-preview-list');
    if (!listEl) return;
    listEl.innerHTML = '<div class="premium-preview-empty">No bookmarks yet. Visit aptosity.com/sync to add some.</div>';
  }

  function showPreviewError(message) {
    var listEl = document.getElementById('premium-preview-list');
    if (!listEl) return;
    listEl.innerHTML = '<div class="premium-preview-error">' + escapeHtmlPremium(message) + '</div>';
  }

  /**
   * Escape HTML to prevent XSS in preview rendering.
   * (Separate from the sync-page.js escapeHtml to avoid scope issues.)
   */
  function escapeHtmlPremium(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // ── Modal: Add / Edit ───────────────────────────────────────
  function openAddModal(parentNode) {
    modalMode = 'add';
    modalEditNode = null;
    modalAddParent = parentNode || currentFolderNode && currentFolderNode.id !== '__root__' ? currentFolderNode : null;
    modalType = 'bookmark';
    modalTitleEl.textContent = modalAddParent
      ? 'Add to ' + (modalAddParent.title || 'folder')
      : 'Add bookmark';
    modalTitleInput.value = '';
    modalUrlInput.value = '';
    modalError.textContent = '';
    modalError.className = 'setting-hint';
    // Show type selector + URL field
    modalTypeGroup.style.display = '';
    modalUrlGroup.style.display = '';
    setTypeButtonState('bookmark');
    modalOverlay.classList.add('visible');
    setTimeout(function () { modalTitleInput.focus(); }, 50);
  }

  // Open add modal pre-filled with the current page info
  function openAddModalForPage(url, title) {
    modalMode = 'add';
    modalEditNode = null;
    modalAddParent = currentFolderNode && currentFolderNode.id !== '__root__' ? currentFolderNode : null;
    modalType = 'bookmark';
    modalTitleEl.textContent = 'Bookmark this page';
    modalTitleInput.value = title || '';
    modalUrlInput.value = url || '';
    modalError.textContent = '';
    modalError.className = 'setting-hint';
    // Hide type selector (always a bookmark), show URL field
    modalTypeGroup.style.display = 'none';
    modalUrlGroup.style.display = '';
    setTypeButtonState('bookmark');
    modalOverlay.classList.add('visible');
    setTimeout(function () { modalTitleInput.focus(); }, 50);
  }

  // Open add modal for folder creation
  function openAddModalForFolder() {
    modalMode = 'add';
    modalEditNode = null;
    modalAddParent = currentFolderNode && currentFolderNode.id !== '__root__' ? currentFolderNode : null;
    modalType = 'folder';
    modalTitleEl.textContent = modalAddParent
      ? 'Add folder to ' + (modalAddParent.title || 'folder')
      : 'Add folder';
    modalTitleInput.value = '';
    modalUrlInput.value = '';
    modalError.textContent = '';
    modalError.className = 'setting-hint';
    // Hide type selector (always a folder), hide URL field
    modalTypeGroup.style.display = 'none';
    modalUrlGroup.style.display = 'none';
    setTypeButtonState('folder');
    modalOverlay.classList.add('visible');
    setTimeout(function () { modalTitleInput.focus(); }, 50);
  }

  function openEditModal(node) {
    modalMode = 'edit';
    modalEditNode = node;
    modalAddParent = null;
    modalType = node.children ? 'folder' : 'bookmark';
    modalTitleEl.textContent = modalType === 'folder' ? 'Edit folder' : 'Edit bookmark';
    modalTitleInput.value = node.title || '';
    modalUrlInput.value = node.url || '';
    modalError.textContent = '';
    modalError.className = 'setting-hint';
    // Hide type selector — can't change bookmark <-> folder
    modalTypeGroup.style.display = 'none';
    modalUrlGroup.style.display = modalType === 'bookmark' ? '' : 'none';
    setTypeButtonState(modalType);
    modalOverlay.classList.add('visible');
    setTimeout(function () { modalTitleInput.focus(); }, 50);
  }

  function setTypeButtonState(type) {
    modalType = type;
    modalTypeBookmark.classList.toggle('active', type === 'bookmark');
    modalTypeFolder.classList.toggle('active', type === 'folder');
    modalUrlGroup.style.display = type === 'bookmark' ? '' : 'none';
  }

  modalTypeBookmark.addEventListener('click', function () { setTypeButtonState('bookmark'); });
  modalTypeFolder.addEventListener('click', function () { setTypeButtonState('folder'); });

  modalCancel.addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', function (e) {
    if (e.target === modalOverlay) closeModal();
  });

  function closeModal() {
    modalOverlay.classList.remove('visible');
    modalEditNode = null;
    modalAddParent = null;
  }

  modalSave.addEventListener('click', async function () {
    var title = modalTitleInput.value.trim();
    var url = modalUrlInput.value.trim();
    modalError.textContent = '';
    modalError.className = 'setting-hint';

    if (!title) {
      modalError.textContent = 'Title is required.';
      modalError.className = 'setting-hint error';
      return;
    }
    if (modalType === 'bookmark' && !url) {
      modalError.textContent = 'URL is required for a bookmark.';
      modalError.className = 'setting-hint error';
      return;
    }
    if (modalType === 'bookmark' && !/^https?:\/\//i.test(url)) {
      // Auto-prepend https://
      url = 'https://' + url;
      modalUrlInput.value = url;
    }

    modalSave.disabled = true;
    modalSave.textContent = 'Saving…';

    try {
      if (modalMode === 'add') {
        var payload = {
          parentId: modalAddParent ? modalAddParent.id : null,
          title: title,
          type: modalType,
        };
        if (modalType === 'bookmark') payload.url = url;
        var res = await send({ type: 'ADD_NODE', payload: payload });
        // Update local tree from cache
        var state = (await send({ type: 'GET_STATE' })).state || {};
        rootTree = state.aptosity_cached_tree || [];
        refreshCurrentFolderNode();
        toast('Added ' + modalType, 'success');
        closeModal();
        renderView();
      } else if (modalMode === 'edit' && modalEditNode) {
        var updPayload = { id: modalEditNode.id, title: title };
        if (modalType === 'bookmark') updPayload.url = url;
        await send({ type: 'UPDATE_NODE', payload: updPayload });
        var state2 = (await send({ type: 'GET_STATE' })).state || {};
        rootTree = state2.aptosity_cached_tree || [];
        refreshCurrentFolderNode();
        toast('Saved', 'success');
        closeModal();
        renderView();
      }
    } catch (e) {
      modalError.textContent = (e.message || 'Save failed');
      modalError.className = 'setting-hint error';
    } finally {
      modalSave.disabled = false;
      modalSave.textContent = 'Save';
    }
  });

  // ── Move modal ──────────────────────────────────────────────
  function openMoveModal(node) {
    moveNode = node;
    moveError.textContent = '';
    moveError.className = 'setting-hint';
    moveModalTitle.textContent = node.children
      ? 'Move folder "' + (node.title || 'Untitled') + '"'
      : 'Move bookmark "' + (node.title || 'Untitled') + '"';

    // Build folder list
    moveFolderList.textContent = '';

    // Add "Root (top level)" option
    var rootItem = document.createElement('button');
    rootItem.className = 'move-folder-item is-root';
    rootItem.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>' +
      '<span class="move-folder-label">Root (top level)</span>';
    // Mark as current if node is already at root
    var currentParentId = findParentId(rootTree, node.id);
    if (currentParentId === null) {
      rootItem.classList.add('is-current');
    }
    rootItem.addEventListener('click', function () {
      handleMove(node, null); // null = root
    });
    moveFolderList.appendChild(rootItem);

    // Recursively add all folders (not the node itself, not descendants if it's a folder)
    addFolderItems(rootTree, 0, node.id);

    moveOverlay.classList.add('visible');
  }

  function addFolderItems(nodes, depth, excludeId) {
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node.children) continue; // skip bookmarks
      // Skip the node being moved (can't move into itself)
      if (node.id === excludeId) continue;
      // Skip descendants of the moved node (if it's a folder, prevent circular)
      if (excludeId && isDescendant(node, excludeId)) continue;

      var item = document.createElement('button');
      item.className = 'move-folder-item';
      var indent = '';
      for (var d = 0; d < depth; d++) indent += '\u00A0\u00A0\u00A0';
      item.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>' +
        '<span class="move-folder-label">' + indent + (node.title || 'Unnamed Folder') + '</span>';

      // Mark as current if the moved node is already in this folder
      var currentParentId = findParentId(rootTree, moveNode ? moveNode.id : '');
      if (currentParentId === node.id) {
        item.classList.add('is-current');
      }

      (function (folderId) {
        item.addEventListener('click', function () {
          handleMove(moveNode, folderId);
        });
      })(node.id);

      moveFolderList.appendChild(item);

      // Recurse into children
      addFolderItems(node.children, depth + 1, excludeId);
    }
  }

  // Check if a node is a descendant of the node with the given ID
  function isDescendant(potentialDescendant, ancestorId) {
    if (potentialDescendant.id === ancestorId) return true;
    if (potentialDescendant.children) {
      for (var i = 0; i < potentialDescendant.children.length; i++) {
        if (isDescendant(potentialDescendant.children[i], ancestorId)) return true;
      }
    }
    return false;
  }

  // Find the parent ID of a node in the tree (null = root level)
  function findParentId(tree, nodeId) {
    for (var i = 0; i < tree.length; i++) {
      if (tree[i].id === nodeId) return null; // at root
      if (tree[i].children) {
        for (var j = 0; j < tree[i].children.length; j++) {
          if (tree[i].children[j].id === nodeId) return tree[i].id;
        }
        var deeper = findParentIdInSubtree(tree[i].children, nodeId, tree[i].id);
        if (deeper !== undefined) return deeper;
      }
    }
    return undefined;
  }

  function findParentIdInSubtree(nodes, nodeId, parentId) {
    for (var i = 0; i < nodes.length; i++) {
      if (nodes[i].id === nodeId) return parentId;
      if (nodes[i].children) {
        var result = findParentIdInSubtree(nodes[i].children, nodeId, nodes[i].id);
        if (result !== undefined) return result;
      }
    }
    return undefined;
  }

  moveCancel.addEventListener('click', closeMoveModal);
  moveOverlay.addEventListener('click', function (e) {
    if (e.target === moveOverlay) closeMoveModal();
  });

  function closeMoveModal() {
    moveOverlay.classList.remove('visible');
    moveNode = null;
  }

  async function handleMove(node, targetParentId) {
    if (!node || !node.id) return;

    // Check if already in the target
    var currentParent = findParentId(rootTree, node.id);
    if ((currentParent === null && targetParentId === null) ||
        (currentParent === targetParentId)) {
      toast('Already in this location', 'error');
      closeMoveModal();
      return;
    }

    try {
      await send({ type: 'MOVE_NODE', payload: { id: node.id, targetParentId: targetParentId } });
      var state = (await send({ type: 'GET_STATE' })).state || {};
      rootTree = state.aptosity_cached_tree || [];
      refreshCurrentFolderNode();
      toast('Moved successfully', 'success');
      closeMoveModal();
      renderView();
    } catch (e) {
      moveError.textContent = (e.message || 'Move failed');
      moveError.className = 'setting-hint error';
    }
  }

  // ── Delete handler ──────────────────────────────────────────
  async function handleDelete(node) {
    var label = node.children ? 'folder' : 'bookmark';
    var msg = 'Delete ' + label + ' "' + (node.title || 'Untitled') + '"?';
    if (node.children && node.children.length > 0) {
      msg += '\n\nThis will also delete everything inside it.';
    }
    if (!confirm(msg)) return;

    try {
      await send({ type: 'DELETE_NODE', payload: { id: node.id } });
      var state = (await send({ type: 'GET_STATE' })).state || {};
      rootTree = state.aptosity_cached_tree || [];
      refreshCurrentFolderNode();
      // If we just deleted the root folder, fall back to top-level.
      if (rootFolder && rootFolder.id === node.id) {
        rootFolder = null;
        await send({ type: 'SET_ROOT_FOLDER', rootFolder: null });
        updateRootFolderUI();
      }
      toast('Deleted', 'success');
      renderView();
    } catch (e) {
      toast('Delete failed: ' + (e.message || 'error'), 'error');
    }
  }

  // ── Set as root folder ──────────────────────────────────────
  async function handleSetRoot(node) {
    if (!node || !node.id) return;
    var newRoot = { id: node.id, title: node.title || 'Unnamed folder' };
    // Toggle off if already set
    if (rootFolder && rootFolder.id === node.id) {
      newRoot = null;
    }
    try {
      await send({ type: 'SET_ROOT_FOLDER', rootFolder: newRoot });
      rootFolder = newRoot;
      updateRootFolderUI();
      toast(
        newRoot
          ? 'Root folder set to "' + newRoot.title + '"'
          : 'Root folder reset to top-level',
        'success'
      );
      // Navigate INTO the new root so the user sees it immediately
      if (newRoot) {
        navigateToRootFolder();
      } else {
        currentFolderNode = null;
        navStack = [];
        updateNavBar();
        renderView();
      }
    } catch (e) {
      toast('Could not set root: ' + (e.message || 'error'), 'error');
    }
  }

  // Navigate to the root folder (if set), otherwise to the top level.
  function navigateToRootFolder() {
    if (!rootFolder) {
      currentFolderNode = null;
      navStack = [];
      updateNavBar();
      renderView();
      return;
    }
    // Find the folder node in the tree by id
    var found = findNodeById(rootTree, rootFolder.id);
    if (found) {
      // Update the title from the tree in case it was renamed
      rootFolder.title = found.title || rootFolder.title;
      currentFolderNode = found;
      navStack = [];
      updateNavBar();
      renderView();
    } else {
      // The folder was deleted or not found — fall back to top-level
      rootFolder = null;
      send({ type: 'SET_ROOT_FOLDER', rootFolder: null }).catch(function () {});
      updateRootFolderUI();
      currentFolderNode = null;
      navStack = [];
      updateNavBar();
      renderView();
      toast('Your root folder was not found — reset to top-level', 'error');
    }
  }

  function findNodeById(tree, id) {
    if (!tree || !id) return null;
    for (var i = 0; i < tree.length; i++) {
      if (tree[i].id === id) return tree[i];
      if (tree[i].children) {
        var found = findNodeById(tree[i].children, id);
        if (found) return found;
      }
    }
    return null;
  }

  /**
   * After rootTree is updated (from cache), re-sync currentFolderNode
   * and navStack to point into the FRESH tree. Without this, mutations
   * (add / edit / delete / move) render stale children because
   * currentFolderNode still references the old tree object.
   */
  function refreshCurrentFolderNode() {
    if (!currentFolderNode || !rootTree) return;

    if (currentFolderNode.id === '__root__') {
      // Virtual root — just rebuild it from rootTree
      currentFolderNode = {
        id: '__root__',
        title: 'Root',
        children: rootTree.slice()
      };
    } else {
      // Find the same folder in the fresh tree
      var fresh = findNodeById(rootTree, currentFolderNode.id);
      if (fresh && fresh.children) {
        currentFolderNode = fresh;
      } else {
        // Folder was deleted or not found — fall back to root
        currentFolderNode = {
          id: '__root__',
          title: 'Root',
          children: rootTree.slice()
        };
      }
    }

    // Rebuild navStack with fresh references
    var freshStack = [];
    for (var i = 0; i < navStack.length; i++) {
      var oldNode = navStack[i];
      if (!oldNode) continue;
      if (oldNode.id === '__root__') {
        freshStack.push({
          id: '__root__',
          title: 'Root',
          children: rootTree.slice()
        });
      } else {
        var freshNode = findNodeById(rootTree, oldNode.id);
        if (freshNode && freshNode.children) {
          freshStack.push(freshNode);
        }
        // If not found (deleted), skip it — the stack collapses
      }
    }
    navStack = freshStack;
    updateNavBar();
    updateRootFolderUI();
  }

  // Update the Settings panel row + the nav-bar home button visibility.
  function updateRootFolderUI() {
    if (rootFolderName) {
      rootFolderName.textContent = rootFolder
        ? rootFolder.title || 'Unnamed folder'
        : 'Top-level (default)';
    }
    // Show the home button in the nav bar only if we have a root set AND
    // we're not currently inside it.
    if (rootHomeBtn) {
      var insideRoot = rootFolder &&
        currentFolderNode &&
        currentFolderNode.id === rootFolder.id;
      var atTopLevel = !currentFolderNode || currentFolderNode.id === '__root__';
      rootHomeBtn.style.display = (rootFolder && !insideRoot) ? '' : 'none';
      // Also show when at top-level but root is set (so user can jump back in)
      if (rootFolder && atTopLevel) {
        rootHomeBtn.style.display = '';
      }
    }
  }

  // Reset root button (in Settings)
  if (cfgResetRoot) {
    cfgResetRoot.addEventListener('click', async function () {
      if (!rootFolder) return;
      if (!confirm('Reset your root folder to top-level?')) return;
      try {
        await send({ type: 'SET_ROOT_FOLDER', rootFolder: null });
        rootFolder = null;
        updateRootFolderUI();
        currentFolderNode = null;
        navStack = [];
        updateNavBar();
        renderView();
        toast('Root folder reset to top-level', 'success');
      } catch (e) {
        toast('Could not reset root: ' + (e.message || 'error'), 'error');
      }
    });
  }

  // Root home button (in nav bar) — jump straight to the root folder
  if (rootHomeBtn) {
    rootHomeBtn.addEventListener('click', function () {
      navigateToRootFolder();
    });
  }

  // ── Boot ────────────────────────────────────────────────────
  async function boot() {
    try {
      var state = (await send({ type: 'GET_STATE' })).state || {};
      var hasToken = !!state.aptosity_token;

      // CACHE-FIRST: render cached tree instantly. This makes the popup
      // feel zero-latency, even before we hit the network.
      rootTree = state.aptosity_cached_tree || null;
      var cachedUser = state.aptosity_cached_user || null;
      // Load saved root folder (if any)
      rootFolder = state.aptosity_root_folder || null;
      updateRootFolderUI();

      if (!hasToken) {
        connectionInfo = null;
        showSignedOut();
        renderView();
        return;
      }

      // If we have a cached user, optimistically show signed-in state.
      // BUT: if we have a cached "premium required" flag from last time,
      // show the premium UI immediately (avoids flashing bookmarks).
      var cachedPremiumRequired = state.aptosity_cached_premium_required || false;
      if (cachedPremiumRequired) {
        showPremiumRequired(state.aptosity_cached_premium || null);
        renderView();
        // Still fall through to TEST_CONNECTION so we can detect if the
        // user has since paid (the catch block will reload on success).
      } else if (cachedUser) {
        connectionInfo = { user: cachedUser };
        showSignedIn();
        // IMPORTANT: do NOT open settings panel — go straight to bookmarks.
        settingsPanel.classList.remove('visible');
        settingsToggle.classList.remove('active');
        // If we have a cached tree AND a root folder, jump straight to root.
        if (rootTree && rootFolder) {
          navigateToRootFolder();
        } else {
          renderView();
        }
      } else {
        // No cached user — we still need to test the connection.
        // Show a loading state while we wait.
        renderView();
      }

      // Background verify + refresh. If the token is invalid, we'll
      // re-show the sign-in panel.
      try {
        var test = await send({ type: 'TEST_CONNECTION' });
        connectionInfo = test.status;
        showSignedIn();
        // If we have a cached tree, render it right away
        if (rootTree) {
          // Tree is already rendered from cache; just make sure UI is right.
          settingsPanel.classList.remove('visible');
          settingsToggle.classList.remove('active');
          // If a root folder is set, navigate to it on every boot.
          if (rootFolder) {
            navigateToRootFolder();
          } else {
            renderView();
          }
        } else {
          // No cache — fetch now
          renderView(); // shows loading
          try {
            await send({ type: 'FETCH_BOOKMARKS' });
            var s2 = (await send({ type: 'GET_STATE' })).state || {};
            rootTree = s2.aptosity_cached_tree || [];
            if (rootFolder) {
              navigateToRootFolder();
            } else {
              renderView();
            }
          } catch (e) {
            rootTree = rootTree || [];
            renderView();
            toast('Using cached bookmarks (offline?)', 'error');
          }
        }

        // Background refresh — fetch latest silently (no toast).
        // Only if cache is older than 60 seconds.
        var cachedAt = state.aptosity_cached_at || 0;
        if (Date.now() - cachedAt > 60000) {
          send({ type: 'FETCH_BOOKMARKS' }).then(function () {
            // Silently update cache; the next popup open will use it.
          }).catch(function () {});
        }
      } catch (e) {
        // Token rejected, premium required, or network error
        if (e.code === 'PREMIUM_REQUIRED') {
          // User is signed in but premium is required/inactive.
          // Show the premium-required UI with status detail.
          showPremiumRequired(e.premium || null);
          renderView();
        } else if (e.code === 'HTTP_401') {
          connectionInfo = null;
          rootTree = null;
          showSignedOut();
          signinError.textContent = 'Token rejected. Update it below.';
          signinError.className = 'setting-hint error';
          renderView();
        } else if (rootTree) {
          // Network error but we have cache — keep showing it.
          toast('Offline — showing cached bookmarks', 'error');
        } else {
          connectionInfo = null;
          showSignedOut();
          renderView();
        }
      }
    } catch (e) {
      connectionInfo = null;
      showSignedOut();
      renderView();
    }
  }

  boot();
})();
