/**
 * Aptosity Bookmarks – background service worker.
 *
 * The site URL is hardcoded to https://aptosity.com — the user only pastes
 * their token. The extension:
 *   - Holds the user's sync token (chrome.storage.sync)
 *   - Caches the bookmark tree locally (chrome.storage.local) for offline use
 *   - Provides a high-level API client (AptosityAPI) for the popup
 *   - Exposes message handlers the popup can call for read AND mutation
 *
 * chrome.bookmarks is only touched by the one-time SEED_FROM_BROWSER action,
 * which reads the browser's tree and POSTs it to the site (overwriting the
 * user's profile there).
 */

// Hardcoded — the extension only ever talks to aptosity.com.
const SITE_URL = 'https://aptosity.com';
const REST_BASE = SITE_URL + '/wp-json/aptosity/v1';

const SYNC_KEYS = {
  token: 'aptosity_token',
};

const LOCAL_KEYS = {
  cachedTree:           'aptosity_cached_tree',
  cachedAt:             'aptosity_cached_at',
  cachedItemCount:      'aptosity_cached_count',
  cachedUser:           'aptosity_cached_user',
  rootFolder:           'aptosity_root_folder',
  // Premium cache (7-day TTL — see PREMIUM_CACHE_TTL_MS).
  cachedPremium:           'aptosity_cached_premium',
  cachedPremiumAt:         'aptosity_cached_premium_at',
  cachedPremiumRequired:   'aptosity_cached_premium_required',
  // Preview tree cache (for non-premium locked preview).
  cachedPreviewTree:       'aptosity_cached_preview_tree',
  cachedPreviewAt:         'aptosity_cached_preview_at',
  cachedPreviewCount:      'aptosity_cached_preview_count',
};

// 7-day cache TTL for premium status (in milliseconds).
const PREMIUM_CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000;

// ── Storage helpers ──────────────────────────────────────────

async function getSync(key) {
  const items = await chrome.storage.sync.get({ [key]: '' });
  return items[key];
}

async function setSync(key, value) {
  await chrome.storage.sync.set({ [key]: value });
}

async function getAllState() {
  const syncItems = await chrome.storage.sync.get({ [SYNC_KEYS.token]: '' });
  const localItems = await chrome.storage.local.get({
    [LOCAL_KEYS.cachedTree]:             null,
    [LOCAL_KEYS.cachedAt]:               0,
    [LOCAL_KEYS.cachedItemCount]:        0,
    [LOCAL_KEYS.cachedUser]:             null,
    [LOCAL_KEYS.rootFolder]:             null,
    [LOCAL_KEYS.cachedPremium]:          null,
    [LOCAL_KEYS.cachedPremiumAt]:        0,
    [LOCAL_KEYS.cachedPremiumRequired]:  false,
    [LOCAL_KEYS.cachedPreviewTree]:      null,
    [LOCAL_KEYS.cachedPreviewAt]:        0,
    [LOCAL_KEYS.cachedPreviewCount]:     0,
  });
  return Object.assign({ siteUrl: SITE_URL }, syncItems, localItems);
}

async function getLocal(key, fallback) {
  const items = await chrome.storage.local.get({ [key]: fallback !== undefined ? fallback : null });
  return items[key];
}

async function setLocal(key, value) {
  await chrome.storage.local.set({ [key]: value });
}

// ── API client ───────────────────────────────────────────────

async function apiRequest(path, options = {}) {
  const token = await getSync(SYNC_KEYS.token);
  if (!token) {
    const err = new Error('Not signed in');
    err.code = 'NOT_CONFIGURED';
    throw err;
  }
  const url = REST_BASE + path;
  const headers = {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json',
  };
  const res = await fetch(url, {
    method: options.method || 'GET',
    headers,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let json;
  try {
    json = await res.json();
  } catch (e) {
    json = null;
  }
  if (!res.ok) {
    // Detect premium-required (402 + aptosity_premium_required code).
    // Surface as a distinct error code so the popup can show the
    // upgrade UI instead of the sign-in UI.
    if (res.status === 402 && json && json.code === 'aptosity_premium_required') {
      const err = new Error(json.message || 'Premium required');
      err.code = 'PREMIUM_REQUIRED';
      err.status = res.status;
      err.body = json;
      // Attach the premium status object if the server included one
      // (it's in additional_data.premium per WP_Error convention).
      err.premium = (json && json.additional_data && json.additional_data.premium) || null;
      throw err;
    }
    const err = new Error((json && json.message) || ('HTTP ' + res.status));
    err.code = (json && json.code) || ('HTTP_' + res.status);
    err.status = res.status;
    err.body = json;
    throw err;
  }
  return json;
}

const api = {
  status:    ()             => apiRequest('/status'),
  getTree:   ()             => apiRequest('/bookmarks'),
  getTreePreview: ()        => apiRequest('/bookmarks/preview'),
  pushTree:  (tree)         => apiRequest('/bookmarks', { method: 'POST', body: { tree } }),
  addNode:   (payload)      => apiRequest('/bookmarks/add',    { method: 'POST', body: payload }),
  updateNode:(payload)      => apiRequest('/bookmarks/update', { method: 'POST', body: payload }),
  deleteNode:(payload)      => apiRequest('/bookmarks/delete', { method: 'POST', body: payload }),
  moveNode:  (payload)      => apiRequest('/bookmarks/move',   { method: 'POST', body: payload }),
};

// ── Cache helpers ────────────────────────────────────────────

async function writeCache(tree, count, user) {
  await setLocal(LOCAL_KEYS.cachedTree, tree);
  await setLocal(LOCAL_KEYS.cachedItemCount, count);
  await setLocal(LOCAL_KEYS.cachedAt, Date.now());
  if (user) {
    await setLocal(LOCAL_KEYS.cachedUser, user);
  }
}

async function clearCache() {
  await chrome.storage.local.remove([
    LOCAL_KEYS.cachedTree,
    LOCAL_KEYS.cachedAt,
    LOCAL_KEYS.cachedItemCount,
    LOCAL_KEYS.cachedUser,
  ]);
}

function countItems(tree) {
  if (!Array.isArray(tree)) return 0;
  let n = 0;
  const walk = (nodes) => {
    for (const node of nodes) {
      n++;
      if (Array.isArray(node.children)) walk(node.children);
    }
  };
  walk(tree);
  return n;
}

/**
 * Fetch the latest tree from the site and cache it locally.
 */
async function fetchAndCacheBookmarks() {
  const data = await api.getTree();
  const tree = (data && data.tree) || [];
  const count = (data && data.itemCount) || countItems(tree);
  await writeCache(tree, count, null);
  return { tree, count, updatedAt: data && data.updatedAt };
}

// ── Bookmark tree conversion (for SEED_FROM_BROWSER) ────────

function chromeNodeToSyncNode(node) {
  const out = { title: node.title || '' };
  if (node.url) {
    out.url = node.url;
  }
  if (Array.isArray(node.children)) {
    out.children = node.children
      .filter(c => c.title || c.url)
      .map(chromeNodeToSyncNode);
  }
  if (node.dateAdded) {
    out.dateAdded = node.dateAdded;
  }
  return out;
}

async function readChromeBookmarkTree() {
  return new Promise((resolve, reject) => {
    chrome.bookmarks.getTree(tree => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(tree);
    });
  });
}

/**
 * SEED_FROM_BROWSER — read the local Chrome bookmark tree, push it to the
 * site as the user's bookmark profile (overwriting whatever's there),
 * then refresh local cache.
 */
async function seedFromBrowser() {
  const tree = await readChromeBookmarkTree();
  const syncTree = tree.map(chromeNodeToSyncNode);
  const total = countItems(syncTree);
  const result = await api.pushTree(syncTree);
  // Refresh local cache immediately from server response (it has IDs).
  const serverTree = (result && result.tree) || syncTree;
  await writeCache(serverTree, result.itemCount || total, null);
  return {
    ok: true,
    itemCount: result.itemCount || total,
    updatedAt: result.updatedAt,
  };
}

/**
 * EXPORT_BOOKMARKS_HTML — convert the user's cached bookmark tree into
 * the Netscape Bookmark file format and trigger a download via a Blob URL.
 *
 * If the cache is empty or stale, we try a fresh fetch first. If that
 * also fails (no token, network error, premium required), we throw.
 *
 * @returns {Promise<{ok: true, itemCount: number, filename: string}>}
 */
async function exportBookmarksHtml() {
  // Try to use the cached tree. If empty or older than 60s, refresh first
  // so we don't export stale data.
  let tree = await getLocal(LOCAL_KEYS.cachedTree, null);
  let itemCount = await getLocal(LOCAL_KEYS.cachedItemCount, 0);
  const cachedAt = await getLocal(LOCAL_KEYS.cachedAt, 0);

  if ((!tree || tree.length === 0) || (Date.now() - cachedAt > 60000)) {
    // Refresh from server.
    const data = await fetchAndCacheBookmarks();
    tree = data.tree || [];
    itemCount = data.count || 0;
  }

  if (!tree || tree.length === 0) {
    const err = new Error('No bookmarks to export.');
    err.code = 'EMPTY_TREE';
    throw err;
  }

  const html = treeToNetscapeHtml(tree);
  const filename = 'bookmarks-' + new Date().toISOString().slice(0, 10) + '.html';

  // Service workers (Manifest V3) don't support URL.createObjectURL or Blob.
  // Use a data: URI instead — chrome.downloads.download() accepts it.
  const url = 'data:text/html;charset=UTF-8,' + encodeURIComponent(html);

  await new Promise((resolve, reject) => {
    chrome.downloads.download({
      url: url,
      filename: filename,
      saveAs: true,  // prompt user for location
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(downloadId);
    });
  });

  return { ok: true, itemCount, filename };
}

/**
 * Convert a bookmark tree (array of nodes) into Netscape Bookmark HTML.
 *
 * Node shape: { id, title, url?, children?, dateAdded? }
 *
 * @param {Array} tree Root-level nodes.
 * @returns {string} Netscape-format HTML.
 */
function treeToNetscapeHtml(tree) {
  if (!Array.isArray(tree)) return '';
  let out = '';
  out += '<!DOCTYPE NETSCAPE-Bookmark-file-1>\n';
  out += '<!-- This is an automatically generated file.\n';
  out += '     It will be read and overwritten.\n';
  out += '     Generated by Aptosity Bookmarks on ' + new Date().toISOString() + ' -->\n';
  out += '<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n';
  out += '<TITLE>Bookmarks</TITLE>\n';
  out += '<H1>Bookmarks</H1>\n';
  out += '<DL><p>\n';
  for (const node of tree) {
    out += nodeToNetscape(node, 1);
  }
  out += '</DL><p>\n';
  return out;
}

/**
 * Recursively render a single bookmark node.
 *
 * @param {object} node  Bookmark node.
 * @param {number} depth Indentation depth.
 * @returns {string}
 */
function nodeToNetscape(node, depth) {
  if (!node || typeof node !== 'object') return '';
  const indent = '    '.repeat(depth);
  const title = escapeHtml(node.title || '');

  // Folder node (has children).
  if (Array.isArray(node.children)) {
    let out = indent + '<DT><H3>' + title + '</H3>\n';
    out += indent + '<DL><p>\n';
    for (const child of node.children) {
      out += nodeToNetscape(child, depth + 1);
    }
    out += indent + '</DL><p>\n';
    return out;
  }

  // Bookmark node (has URL).
  if (node.url) {
    let add = '';
    if (node.dateAdded) {
      // Chrome stores dateAdded as ms since epoch; Netscape uses seconds.
      const ts = typeof node.dateAdded === 'number'
        ? Math.floor(node.dateAdded / 1000)
        : Math.floor(Date.parse(node.dateAdded) / 1000);
      if (ts > 0) add = ' ADD_DATE="' + ts + '"';
    }
    return indent + '<DT><A HREF="' + escapeHtml(node.url) + '"' + add + '>' + title + '</A>\n';
  }

  // Empty folder (no url, no children).
  let out = indent + '<DT><H3>' + title + '</H3>\n';
  out += indent + '<DL><p>\n';
  out += indent + '</DL><p>\n';
  return out;
}

function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * SYNC_EXTENSIONS — read the browser's installed extensions via
 * chrome.management, construct Chrome Web Store URLs for each, and
 * POST them to the /extensions/sync endpoint.
 *
 * This endpoint is token-only (NO premium required), so ALL logged-in
 * users can sync their extensions. The server reads the existing tree,
 * finds or creates an "Extensions" folder, and replaces its children.
 *
 * @returns {Promise<{ok: true, count: number}>}
 */
async function syncExtensions() {
  // Get installed extensions.
  const extList = await new Promise((resolve, reject) => {
    chrome.management.getAll((extensions) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(extensions);
    });
  });

  // Filter: only normal extensions (not themes, not component extensions).
  // Skip ourselves (the Aptosity Bookmarks extension).
  const selfId = chrome.runtime.id;
  const filtered = extList.filter(ext => {
    if (ext.id === selfId) return false;
    if (ext.type && ext.type !== 'extension') return false;
    if (ext.installType === 'component') return false;
    return true;
  });

  if (filtered.length === 0) {
    return { ok: true, count: 0, message: 'No extensions to sync.' };
  }

  // Build the extensions array for the API.
  const extensions = filtered.map(ext => ({
    title: ext.name || 'Unknown Extension',
    url: 'https://chromewebstore.google.com/detail/' + ext.id,
  }));

  // POST to /extensions/sync (token-only, no premium required).
  const result = await apiRequest('/extensions/sync', {
    method: 'POST',
    body: { extensions: extensions },
  });

  // Update local cache if we got a tree back.
  if (result && result.tree) {
    await writeCache(result.tree, result.itemCount || countItems(result.tree), null);
  }

  return {
    ok: true,
    count: extensions.length,
  };
}

// ── Mutation handlers ────────────────────────────────────────
//
// Each mutation: call the API, then update the local cache from the
// server's returned tree. This keeps the cache in sync immediately.

async function handleAddNode(payload) {
  const result = await api.addNode(payload);
  if (result && result.tree) {
    await writeCache(result.tree, result.itemCount, null);
  }
  return result;
}

async function handleUpdateNode(payload) {
  const result = await api.updateNode(payload);
  if (result && result.tree) {
    await writeCache(result.tree, result.itemCount, null);
  }
  return result;
}

async function handleDeleteNode(payload) {
  const result = await api.deleteNode(payload);
  if (result && result.tree) {
    await writeCache(result.tree, result.itemCount, null);
  }
  return result;
}

async function handleMoveNode(payload) {
  const result = await api.moveNode(payload);
  if (result && result.tree) {
    await writeCache(result.tree, result.itemCount, null);
  }
  return result;
}

/**
 * SIGN_OUT — clear sync config + local cache + root folder preference
 * + premium cache + preview cache.
 */
async function signOut() {
  await chrome.storage.sync.remove([SYNC_KEYS.token]);
  await clearCache();
  await chrome.storage.local.remove([LOCAL_KEYS.rootFolder]);
  await chrome.storage.local.remove([
    LOCAL_KEYS.cachedPremium,
    LOCAL_KEYS.cachedPremiumAt,
    LOCAL_KEYS.cachedPremiumRequired,
  ]);
  await chrome.storage.local.remove([
    LOCAL_KEYS.cachedPreviewTree,
    LOCAL_KEYS.cachedPreviewAt,
    LOCAL_KEYS.cachedPreviewCount,
  ]);
}

// ── Message handler (popup → background) ─────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      switch (message.type) {
        case 'GET_STATE': {
          const state = await getAllState();
          sendResponse({ ok: true, state });
          break;
        }
        case 'SAVE_TOKEN': {
          await setSync(SYNC_KEYS.token, (message.token || '').trim());
          sendResponse({ ok: true });
          break;
        }
        case 'TEST_CONNECTION': {
          try {
            const status = await api.status();
            // Cache the user info so the popup can render instantly next time.
            if (status && status.user) {
              await setLocal(LOCAL_KEYS.cachedUser, status.user);
            }
            // Cache the premium status + clear the premium-required flag.
            if (status && status.premium) {
              await setLocal(LOCAL_KEYS.cachedPremium, status.premium);
              await setLocal(LOCAL_KEYS.cachedPremiumAt, Date.now());
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, !status.premium.isActive);
            }
            sendResponse({ ok: true, status });
          } catch (e) {
            // If premium required, cache the state so the popup can show
            // the premium UI instantly on next open.
            if (e.code === 'PREMIUM_REQUIRED') {
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, true);
              if (e.premium) {
                await setLocal(LOCAL_KEYS.cachedPremium, e.premium);
                await setLocal(LOCAL_KEYS.cachedPremiumAt, Date.now());
              }
            }
            throw e;
          }
          break;
        }
        case 'CHECK_PREMIUM': {
          // Return cached premium status if still within TTL; otherwise
          // force a fresh /status call. This is the 7-day grace cache
          // that lets the extension work offline / avoid re-checking on
          // every popup open.
          const cachedAt = await getLocal(LOCAL_KEYS.cachedPremiumAt, 0);
          const age = Date.now() - (cachedAt || 0);
          if (age < PREMIUM_CACHE_TTL_MS) {
            const cached = await getLocal(LOCAL_KEYS.cachedPremium, null);
            if (cached) {
              sendResponse({ ok: true, premium: cached, cached: true });
              break;
            }
          }
          // Cache miss or stale — fetch fresh.
          try {
            const status = await api.status();
            if (status && status.premium) {
              await setLocal(LOCAL_KEYS.cachedPremium, status.premium);
              await setLocal(LOCAL_KEYS.cachedPremiumAt, Date.now());
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, !status.premium.isActive);
              sendResponse({ ok: true, premium: status.premium, cached: false });
            } else {
              sendResponse({ ok: true, premium: null, cached: false });
            }
          } catch (e) {
            // If premium required, return that status (don't error out).
            if (e.code === 'PREMIUM_REQUIRED') {
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, true);
              sendResponse({ ok: true, premium: e.premium || null, cached: false });
            } else {
              throw e;
            }
          }
          break;
        }
        case 'REFRESH_PREMIUM': {
          // Force a fresh /status call (bypasses the 7-day cache).
          // Used by the "I've paid — refresh" button in the premium UI.
          try {
            const status = await api.status();
            if (status && status.premium) {
              await setLocal(LOCAL_KEYS.cachedPremium, status.premium);
              await setLocal(LOCAL_KEYS.cachedPremiumAt, Date.now());
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, !status.premium.isActive);
              sendResponse({ ok: true, premium: status.premium });
            } else {
              sendResponse({ ok: true, premium: null });
            }
          } catch (e) {
            if (e.code === 'PREMIUM_REQUIRED') {
              await setLocal(LOCAL_KEYS.cachedPremiumRequired, true);
              sendResponse({ ok: true, premium: e.premium || null });
            } else {
              throw e;
            }
          }
          break;
        }
        case 'FETCH_BOOKMARKS': {
          const result = await fetchAndCacheBookmarks();
          sendResponse({ ok: true, result });
          break;
        }
        case 'FETCH_BOOKMARKS_PREVIEW': {
          // Fetch the URL-stripped preview tree (for non-premium locked
          // preview in the popup). This endpoint does NOT require premium.
          const data = await api.getTreePreview();
          const tree = (data && data.tree) || [];
          const count = (data && data.itemCount) || 0;
          await setLocal(LOCAL_KEYS.cachedPreviewTree, tree);
          await setLocal(LOCAL_KEYS.cachedPreviewCount, count);
          await setLocal(LOCAL_KEYS.cachedPreviewAt, Date.now());
          sendResponse({ ok: true, result: { tree, itemCount: count } });
          break;
        }
        case 'SEED_FROM_BROWSER': {
          const result = await seedFromBrowser();
          sendResponse({ ok: true, result });
          break;
        }
        case 'EXPORT_BOOKMARKS_HTML': {
          const result = await exportBookmarksHtml();
          sendResponse({ ok: true, result });
          break;
        }
        case 'ADD_NODE': {
          const result = await handleAddNode(message.payload || {});
          sendResponse({ ok: true, result });
          break;
        }
        case 'UPDATE_NODE': {
          const result = await handleUpdateNode(message.payload || {});
          sendResponse({ ok: true, result });
          break;
        }
        case 'DELETE_NODE': {
          const result = await handleDeleteNode(message.payload || {});
          sendResponse({ ok: true, result });
          break;
        }
        case 'MOVE_NODE': {
          const result = await handleMoveNode(message.payload || {});
          sendResponse({ ok: true, result });
          break;
        }
        case 'SYNC_EXTENSIONS': {
          const result = await syncExtensions();
          sendResponse({ ok: true, result });
          break;
        }
        case 'GET_EXTENSION_ZIP_URL': {
          const result = await apiRequest('/extensions/zip-url');
          sendResponse({ ok: true, result });
          break;
        }
        case 'SIGN_OUT': {
          await signOut();
          sendResponse({ ok: true });
          break;
        }
        case 'SET_ROOT_FOLDER': {
          const rootFolder = message.rootFolder || null;
          await setLocal(LOCAL_KEYS.rootFolder, rootFolder);
          sendResponse({ ok: true });
          break;
        }
        case 'GET_CURRENT_TAB': {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tabs && tabs.length > 0 && tabs[0].url) {
            sendResponse({ ok: true, tab: { url: tabs[0].url, title: tabs[0].title || '' } });
          } else {
            sendResponse({ ok: true, tab: null });
          }
          break;
        }
        default:
          sendResponse({ ok: false, error: 'Unknown message type: ' + message.type });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e.message, code: e.code || null, status: e.status || null });
    }
  })();
  return true; // async
});

// On install / startup, refresh the cache in the background so the popup
// opens instantly next time.
chrome.runtime.onInstalled.addListener(() => {
  // Best-effort background refresh.
  (async () => {
    try {
      const token = await getSync(SYNC_KEYS.token);
      if (token) {
        await fetchAndCacheBookmarks();
      }
    } catch (e) {
      // ignore — popup will retry.
    }
  })();
});

chrome.runtime.onStartup.addListener(() => {
  (async () => {
    try {
      const token = await getSync(SYNC_KEYS.token);
      if (token) {
        await fetchAndCacheBookmarks();
      }
    } catch (e) {
      // ignore — popup will retry.
    }
  })();
});
